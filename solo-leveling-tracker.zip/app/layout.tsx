import './globals.css';
import Link from 'next/link';

export const metadata = {
  title: 'Solo Leveling Tracker',
  description: 'RPG fitness tracker with skills, cardio, levels, HP and leaderboards.'
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>
        <header>
          <div className="container hstack">
            <strong>Solo Leveling Tracker</strong>
            <span className="badge">Multi‑User</span>
            <div className="spacer" />
            <Link className="btn" href="/">Dashboard</Link>
            <Link className="btn" href="/leaderboard">Leaderboard</Link>
            <Link className="btn" href="/login">Login</Link>
          </div>
        </header>
        <div className="container">{children}</div>
      </body>
    </html>
  );
}
