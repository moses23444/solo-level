'use client';
import { useEffect, useMemo, useState } from 'react';
import { supabase } from '@/lib/supabaseClient';
import { cardioXP, strengthVolumeXP } from '@/lib/xp';
import { playLevelUpChime } from '@/lib/sound';

type Category = { id: string; name: string; kind: 'skill'|'muscle'|'cardio' };
type Stat = { user_id: string; category_id: string; level:number; xp:number; xp_to_next:number; category?: Category };
type Profile = { id: string; handle: string|null; visibility: 'public'|'private'; hp:number; max_hp:number };

export default function Dashboard(){
  const [session, setSession] = useState<any>(null);
  const [profile, setProfile] = useState<Profile|null>(null);
  const [stats, setStats] = useState<Stat[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);
  const [log, setLog] = useState<string[]>([]);

  useEffect(()=>{
    const load = async () => {
      const { data: { session } } = await supabase.auth.getSession();
      setSession(session);
      const user = session?.user;
      if (!user) return setLoading(false);

      // Ensure profile exists
      await supabase.rpc('ensure_profile');
      // get profile
      const { data: p } = await supabase.from('profiles').select('*').eq('id', user.id).maybeSingle();
      if (p) setProfile(p as Profile);

      // seed stats if needed
      await supabase.rpc('init_user_stats', { p_user: user.id });

      const { data: cats } = await supabase.from('categories').select('*').order('name');
      setCategories(cats || []);

      const { data: st } = await supabase.from('stats').select('*, category:categories(*)').eq('user_id', user.id).order('category(name)');
      setStats((st as any)||[]);

      setLoading(false);
    };
    load();
  }, []);

  async function addStrength(categoryId:string, sets: {reps:number, weight:number}[], note:string){
    const xp = strengthVolumeXP(sets);
    const { data: res, error } = await supabase.rpc('apply_xp', { 
      p_category: categoryId, p_delta: xp, p_source: 'strength', p_note: note || null
    });
    if (error) { alert(error.message); return; }
    setLog(l => [`+${xp} XP to ${nameOf(categoryId)} (Strength)`, ...l]);
    if (res?.leveled_up) playLevelUpChime();
    refreshStats();
  }

  async function addCardio(categoryId:string, distanceKm:number, durationMin:number, pr:boolean, note:string){
    const xp = cardioXP(distanceKm, durationMin, pr);
    const payload = { distanceKm, durationMin, pr };
    await supabase.from('entries').insert({
      category_id: categoryId, type: 'cardio', payload, note
    });
    const { data: res, error } = await supabase.rpc('apply_xp', { 
      p_category: categoryId, p_delta: xp, p_source: 'cardio', p_note: note || null
    });
    if (error) { alert(error.message); return; }
    setLog(l => [`+${xp} XP to ${nameOf(categoryId)} (Cardio)`, ...l]);
    if (res?.leveled_up) playLevelUpChime();
    refreshStats();
  }

  async function takeDamage(delta:number, note:string){
    const { error } = await supabase.rpc('apply_hp', { p_delta: -Math.abs(delta), p_note: note || null });
    if (error) return alert(error.message);
    setLog(l => [ `-${Math.abs(delta)} HP: ${note}`, ...l ]);
    const { data: p } = await supabase.from('profiles').select('*').eq('id', profile?.id).maybeSingle();
    if (p) setProfile(p as any);
  }

  async function refreshStats(){
    const { data: st } = await supabase.from('stats').select('*, category:categories(*)').eq('user_id', profile?.id).order('category(name)');
    setStats((st as any)||[]);
  }

  function nameOf(id:string){ return categories.find(c=>c.id===id)?.name || 'Unknown'; }

  if (!session) {
    return (
      <div style={{maxWidth:700, margin:'40px auto'}} className="card">
        <h3>Welcome</h3>
        <p className="small">Sign in to start tracking. (Use the <b>Login</b> link in the header.)</p>
      </div>
    );
  }

  if (loading || !profile) return <div className="small">Loading...</div>;

  const muscleStats = stats.filter(s=>s.category?.kind==='muscle');
  const skillStats  = stats.filter(s=>s.category?.kind==='skill');
  const cardioStats = stats.filter(s=>s.category?.kind==='cardio');

  return (
    <div className="grid cols-2">
      <div className="card">
        <h3 className="sectionTitle">Player</h3>
        <div className="row">
          <div>
            <div><b>{profile.handle || 'Anonymous Hunter'}</b></div>
            <div className="small">HP: {profile.hp} / {profile.max_hp}</div>
          </div>
          <button className="btn danger" onClick={()=>takeDamage(5, 'Ate junk food')}>Ate Junk Food (-5 ❤)</button>
        </div>
      </div>

      <div className="card">
        <h3 className="sectionTitle">Quick Log</h3>
        <div className="small mono" style={{maxHeight:160, overflow:'auto'}}>
          {log.map((l,i)=>(<div key={i}>{l}</div>))}
        </div>
      </div>

      <div className="card">
        <h3 className="sectionTitle">Strength Entry</h3>
        <StrengthForm categories={categories.filter(c=>c.kind!=='cardio')} onSubmit={addStrength}/>
      </div>

      <div className="card">
        <h3 className="sectionTitle">Cardio Entry</h3>
        <CardioForm categories={categories.filter(c=>c.kind==='cardio')} onSubmit={addCardio}/>
      </div>

      <div className="card">
        <h3 className="sectionTitle">Skills</h3>
        <div className="list">
          {skillStats.map(s=>(<StatRow key={s.category_id} stat={s}/>))}
        </div>
      </div>

      <div className="card">
        <h3 className="sectionTitle">Physique</h3>
        <div className="list">
          {muscleStats.map(s=>(<StatRow key={s.category_id} stat={s}/>))}
        </div>
      </div>

      <div className="card">
        <h3 className="sectionTitle">Cardio Levels</h3>
        <div className="list">
          {cardioStats.map(s=>(<StatRow key={s.category_id} stat={s}/>))}
        </div>
      </div>
    </div>
  );
}

function StatRow({ stat }:{ stat: any }){
  const pct = Math.round((stat.xp / stat.xp_to_next) * 100);
  return (
    <div className="row">
      <div style={{minWidth:140}}><b>{stat.category.name}</b><div className="small">LVL {stat.level}</div></div>
      <div style={{flex:1}}>
        <div className="progress"><div style={{width: pct + '%'}}/></div>
        <div className="small mono">{stat.xp} / {stat.xp_to_next} XP</div>
      </div>
    </div>
  );
}

function StrengthForm({ categories, onSubmit }:{ categories:any[], onSubmit:(categoryId:string, sets:{reps:number, weight:number}[], note:string)=>void }){
  const [categoryId, setCategoryId] = useState(categories[0]?.id||'');
  const [sets, setSets] = useState([{ reps: 8, weight: 20 }]);
  const [note, setNote] = useState('');

  return (
    <div>
      <div className="row">
        <select value={categoryId} onChange={e=>setCategoryId(e.target.value)}>
          {categories.map(c=>(<option key={c.id} value={c.id}>{c.name}</option>))}
        </select>
        <button className="btn" onClick={()=>setSets(s=>[...s, { reps:8, weight:20 }])}>+ Add set</button>
      </div>
      {sets.map((s, i)=>(
        <div key={i} className="row">
          <input className="input" type="number" value={s.reps} onChange={e=>{
            const v=[...sets]; v[i]={...v[i], reps:parseInt(e.target.value||'0')}; setSets(v);
          }} placeholder="reps"/>
          <input className="input" type="number" value={s.weight} onChange={e=>{
            const v=[...sets]; v[i]={...v[i], weight:parseFloat(e.target.value||'0')}; setSets(v);
          }} placeholder="weight (kg)"/>
        </div>
      ))}
      <textarea className="input" placeholder="note (optional)" value={note} onChange={e=>setNote(e.target.value)}/>
      <div style={{height:8}}/>
      <button className="btn brand" onClick={()=>onSubmit(categoryId, sets, note)}>Log Strength & Gain XP</button>
    </div>
  );
}

function CardioForm({ categories, onSubmit }:{ categories:any[], onSubmit:(categoryId:string, distanceKm:number, durationMin:number, pr:boolean, note:string)=>void }){
  const [categoryId, setCategoryId] = useState(categories[0]?.id||'');
  const [distanceKm, setDistanceKm] = useState(1);
  const [durationMin, setDurationMin] = useState(10);
  const [pr, setPr] = useState(false);
  const [note, setNote] = useState('');

  return (
    <div>
      <div className="row">
        <select value={categoryId} onChange={e=>setCategoryId(e.target.value)}>
          {categories.map(c=>(<option key={c.id} value={c.id}>{c.name}</option>))}
        </select>
        <input className="input" type="number" step="0.01" value={distanceKm} onChange={e=>setDistanceKm(parseFloat(e.target.value||'0'))} placeholder="distance (km)"/>
        <input className="input" type="number" step="1" value={durationMin} onChange={e=>setDurationMin(parseFloat(e.target.value||'0'))} placeholder="duration (min)"/>
      </div>
      <div className="row">
        <label className="small"><input type="checkbox" checked={pr} onChange={e=>setPr(e.target.checked)}/> Personal Record</label>
        <div className="spacer"/>
        <span className="small">XP ≈ distance*20 + time*0.5 (+PR)</span>
      </div>
      <textarea className="input" placeholder="note (optional)" value={note} onChange={e=>setNote(e.target.value)}/>
      <div style={{height:8}}/>
      <button className="btn brand" onClick={()=>onSubmit(categoryId, distanceKm, durationMin, pr, note)}>Log Cardio & Gain XP</button>
    </div>
  );
}
