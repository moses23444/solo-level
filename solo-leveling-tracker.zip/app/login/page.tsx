'use client';
import { supabase } from '@/lib/supabaseClient';
import { useState } from 'react';

export default function LoginPage(){
  const [email, setEmail] = useState('');
  const [message, setMessage] = useState('');

  async function signIn() {
    const { error } = await supabase.auth.signInWithOtp({ email });
    if (error) setMessage(error.message);
    else setMessage('Check your email for the magic link.');
  }

  return (
    <div className="card" style={{maxWidth: 520, margin: '40px auto'}}>
      <h3>Login / Sign up</h3>
      <p className="small">Enter your email to receive a magic link.</p>
      <input className="input" placeholder="you@example.com" value={email} onChange={e=>setEmail(e.target.value)} />
      <div style={{height:8}}/>
      <button className="btn brand" onClick={signIn}>Send Magic Link</button>
      <div style={{height:8}}/>
      <div className="small">{message}</div>
    </div>
  );
}
