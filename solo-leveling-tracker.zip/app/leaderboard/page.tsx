'use client';
import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabaseClient';

type Row = { handle: string, total_level: number, public_categories: {name:string, level:number}[] };

export default function Leaderboard(){
  const [rows, setRows] = useState<Row[]>([]);

  useEffect(()=>{
    const load = async () => {
      const { data } = await supabase.from('public_leaderboard').select('*').order('total_level', { ascending: false }).limit(50);
      setRows((data as any) || []);
    };
    load();
  }, []);

  return (
    <div className="card">
      <h3>Leaderboard</h3>
      <table className="table">
        <thead><tr><th>Player</th><th>Total Level</th><th>Highlights</th></tr></thead>
        <tbody>
          {rows.map((r,i)=>(
            <tr key={i}>
              <td>{r.handle}</td>
              <td>{r.total_level}</td>
              <td className="small">
                {r.public_categories?.slice(0,4).map((c:any)=>`${c.name} Lv.${c.level}`).join(' • ')}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
