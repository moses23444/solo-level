-- MUSCLES (Physique)
insert into categories (kind, name) values
('muscle','Back'),('muscle','Rear Delts'),('muscle','Chest'),('muscle','Front Delts'),
('muscle','Quads'),('muscle','Glutes'),('muscle','Biceps'),('muscle','Forearms'),
('muscle','Triceps'),('muscle','Side Delts'),('muscle','Hamstrings'),('muscle','Calves')
on conflict (name) do nothing;

-- SKILLS
insert into categories (kind, name) values
('skill','Planche'),('skill','One Arm Pushup'),('skill','Handstand'),('skill','Front Lever')
on conflict (name) do nothing;

-- CARDIO
insert into categories (kind, name) values
('cardio','Running'),('cardio','Track Laps'),('cardio','Cycling'),('cardio','Rowing'),('cardio','Stairmaster')
on conflict (name) do nothing;
