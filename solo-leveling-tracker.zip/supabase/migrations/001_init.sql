-- Enable UUID extension
create extension if not exists "pgcrypto";
create extension if not exists "uuid-ossp";

-- PROFILES
create table if not exists profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  handle text unique,
  avatar_url text,
  visibility text not null default 'public' check (visibility in ('public','private')),
  hp int not null default 100,
  max_hp int not null default 100,
  created_at timestamp with time zone default now()
);

-- CATEGORIES
create table if not exists categories (
  id uuid primary key default gen_random_uuid(),
  kind text not null check (kind in ('skill','muscle','cardio')),
  name text not null unique,
  base_xp int not null default 100
);

-- STATS per user per category
create table if not exists stats (
  user_id uuid not null references profiles(id) on delete cascade,
  category_id uuid not null references categories(id) on delete cascade,
  level int not null default 1,
  xp int not null default 0,
  xp_to_next int not null default 100,
  primary key (user_id, category_id)
);

-- ENTRIES (generic with payload)
create table if not exists entries (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references profiles(id) on delete cascade,
  category_id uuid not null references categories(id) on delete cascade,
  type text not null check (type in ('strength','cardio','mission','damage')),
  payload jsonb,
  note text,
  created_at timestamp with time zone default now()
);

-- XP EVENTS
create table if not exists xp_events (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references profiles(id) on delete cascade,
  category_id uuid not null references categories(id) on delete cascade,
  delta_xp int not null,
  source text not null,
  note text,
  created_at timestamp with time zone default now()
);

-- HP EVENTS
create table if not exists hp_events (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references profiles(id) on delete cascade,
  delta_hp int not null,
  source text not null,
  note text,
  created_at timestamp with time zone default now()
);

-- XP curve
create or replace function xp_to_next(level int) returns int language sql immutable as $$
  select floor(100 * pow(1.5, greatest(level-1, 0)))::int;
$$;

-- Ensure profile exists for current user
create or replace function ensure_profile() returns void language plpgsql security definer as $$
begin
  insert into profiles(id, handle)
  values (auth.uid(), substring(auth.uid()::text from 1 for 6))
  on conflict (id) do nothing;
end;
$$;

-- Initialize user stats rows for all categories
create or replace function init_user_stats(p_user uuid) returns void language plpgsql as $$
begin
  insert into stats(user_id, category_id, level, xp, xp_to_next)
  select p_user, c.id, 1, 0, 100 from categories c
  on conflict (user_id, category_id) do nothing;
end;
$$;

-- APPLY XP
create or replace function apply_xp(p_category uuid, p_delta int, p_source text, p_note text default null)
returns json language plpgsql as $$
declare
  uid uuid := auth.uid();
  s stats%rowtype;
  leveled boolean := false;
begin
  perform ensure_profile();
  perform init_user_stats(uid);
  insert into xp_events(user_id, category_id, delta_xp, source, note) values (uid, p_category, p_delta, p_source, p_note);
  select * into s from stats where user_id = uid and category_id = p_category for update;
  s.xp := s.xp + p_delta;
  while s.xp >= s.xp_to_next loop
    s.xp := s.xp - s.xp_to_next;
    s.level := s.level + 1;
    s.xp_to_next := xp_to_next(s.level);
    leveled := true;
  end loop;
  update stats set level = s.level, xp = s.xp, xp_to_next = s.xp_to_next where user_id = uid and category_id = p_category;
  return json_build_object('level', s.level, 'xp', s.xp, 'xp_to_next', s.xp_to_next, 'leveled_up', leveled);
end;
$$;

-- APPLY HP (damage/heal, clamped)
create or replace function apply_hp(p_delta int, p_note text default null)
returns void language plpgsql as $$
declare
  uid uuid := auth.uid();
  cur int;
  mx int;
begin
  perform ensure_profile();
  insert into hp_events(user_id, delta_hp, source, note) values (uid, p_delta, case when p_delta<0 then 'damage' else 'heal' end, p_note);
  select hp, max_hp into cur, mx from profiles where id = uid for update;
  cur := greatest(0, least(mx, cur + p_delta));
  update profiles set hp = cur where id = uid;
end;
$$;

-- Public leaderboard view: sums total level for public profiles
create or replace view public_leaderboard as
select p.handle,
       sum(s.level) as total_level,
       json_agg(json_build_object('name', c.name, 'level', s.level) order by s.level desc) as public_categories
from profiles p
join stats s on s.user_id = p.id
join categories c on c.id = s.category_id
where p.visibility = 'public'
group by p.id, p.handle;

-- RLS
alter table profiles enable row level security;
alter table categories enable row level security;
alter table stats enable row level security;
alter table entries enable row level security;
alter table xp_events enable row level security;
alter table hp_events enable row level security;

-- Profiles: owner can select/update; anyone can select public rows
create policy "read own profile" on profiles for select using (id = auth.uid());
create policy "read public profiles" on profiles for select using (visibility='public');
create policy "update own profile" on profiles for update using (id = auth.uid());

-- Categories: readable by anyone, no writes (admin by SQL only)
create policy "read categories" on categories for select using (true);

-- Stats: owner read/write; others none
create policy "read own stats" on stats for select using (user_id = auth.uid());
create policy "update own stats" on stats for update using (user_id = auth.uid());
create policy "insert own stats" on stats for insert with check (user_id = auth.uid());

-- Entries & events: owner only
create policy "own entries r" on entries for select using (user_id = auth.uid());
create policy "own entries w" on entries for insert with check (user_id = auth.uid());
create policy "own entries u" on entries for update using (user_id = auth.uid());

create policy "own xp r" on xp_events for select using (user_id = auth.uid());
create policy "own xp w" on xp_events for insert with check (user_id = auth.uid());
create policy "own hp r" on hp_events for select using (user_id = auth.uid());
create policy "own hp w" on hp_events for insert with check (user_id = auth.uid());
