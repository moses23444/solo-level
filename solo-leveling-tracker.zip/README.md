# Solo Leveling Tracker (Multi‑User)

A dark, card‑based RPG fitness tracker inspired by **Solo Leveling**. Supports **strength** (sets × reps × weight), **cardio** (distance/time), levels & XP per category, **HP damage**, activity log, and **leaderboard**. Plays a Minecraft‑like "level up" chime on level up (synthesized with Web Audio API).

## One‑Click Stack
- **Next.js 14** (App Router, TypeScript)
- **Supabase** (Auth + Postgres + RLS + Realtime)
- **Vercel** (Hosting)

## Quick Start
1. Create a Supabase project → copy **Project URL** and **anon public key**.
2. In Supabase SQL editor, run the contents of `supabase/migrations/001_init.sql` (then `seed.sql`).
3. Click “Authentication → Providers” and enable Email auth.
4. Click “SQL Editor → Run” on the seed to create default categories (muscles, skills, cardio).
5. Create a `.env.local` file (or Vercel Environment Variables) containing:
   ```env
   NEXT_PUBLIC_SUPABASE_URL=...your url...
   NEXT_PUBLIC_SUPABASE_ANON_KEY=...your anon key...
   ```
6. Install & run:
   ```bash
   npm i
   npm run dev
   ```
7. Deploy: push to GitHub → **Vercel** → Import → add env vars → Deploy.

## Notes
- RLS enforces privacy: only **public** profiles are visible on the leaderboard.
- The **XP curve** is progressive: `100 * 1.5^(level-1)` to next level.
- To initialize stats rows for a new user, the app calls the SQL function `init_user_stats(uid)` on first login.

