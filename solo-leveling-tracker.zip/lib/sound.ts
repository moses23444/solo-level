'use client';
// Minecraft‑like XP orb chime using Web Audio API (no copyrighted file)
export function playLevelUpChime() {
  const ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
  const now = ctx.currentTime;
  const notes = [880, 1175, 1568]; // A5, D6, G6 (bright arpeggio)
  notes.forEach((freq, i) => {
    const o = ctx.createOscillator();
    const g = ctx.createGain();
    o.type = 'triangle';
    o.frequency.value = freq;
    g.gain.setValueAtTime(0, now + i*0.08);
    g.gain.linearRampToValueAtTime(0.2, now + i*0.08 + 0.02);
    g.gain.exponentialRampToValueAtTime(0.0001, now + i*0.08 + 0.35);
    o.connect(g).connect(ctx.destination);
    o.start(now + i*0.08);
    o.stop(now + i*0.08 + 0.4);
  });
}
