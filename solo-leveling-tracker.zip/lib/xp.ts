export function xpToNext(level: number): number {
  return Math.floor(100 * Math.pow(1.5, Math.max(level - 1, 0)));
}
export type LevelResult = { level:number; xp:number; xp_to_next:number; leveledUp:boolean };

export function applyLocalXP(level:number, xp:number, delta:number): LevelResult {
  let newXp = xp + delta;
  let newLevel = level;
  let req = xpToNext(newLevel);
  let leveledUp = false;
  while (newXp >= req) {
    newXp -= req;
    newLevel += 1;
    req = xpToNext(newLevel);
    leveledUp = true;
  }
  return { level:newLevel, xp:newXp, xp_to_next:req, leveledUp };
}

// Cardio & Strength scoring
export function strengthVolumeXP(sets: {reps:number, weight:number}[]): number {
  const volumes = sets.map(s => s.reps * s.weight);
  const totalVol = volumes.reduce((a,b)=>a+b,0);
  const top = Math.max(0, ...volumes);
  // Log-scaled to keep reasonable
  const base = Math.round(Math.log10(totalVol + 1) * 25);
  const boost = Math.round(Math.log10(top + 1) * 10);
  return Math.min(250, base + boost); // cap
}

export function cardioXP(distanceKm:number, durationMin:number, pr:boolean=false): number {
  const base = Math.round(distanceKm * 20 + durationMin * 0.5);
  const bonus = pr ? 30 : 0;
  return Math.max(5, Math.min(300, base + bonus));
}
